import sqlite3
from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel
import bcrypt

router = APIRouter()

DATABASE = "users.db"


class User(BaseModel):
    login: str
    password: str


# Создание таблицы пользователей
def create_users_table():
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            login TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL
        )
    """)
    conn.commit()
    conn.close()


create_users_table()


@router.post("/register")
def register(user: User):
    hashed_password = bcrypt.hashpw(user.password.encode(), bcrypt.gensalt())

    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    try:
        cursor.execute("INSERT INTO users (login, password) VALUES (?, ?)",
                       (user.login, hashed_password.decode()))
        conn.commit()
    except sqlite3.IntegrityError:
        raise HTTPException(status_code=400, detail="Пользователь уже существует")
    finally:
        conn.close()

    return {"message": "Регистрация успешна"}


@router.post("/login")
def login(user: User):
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    cursor.execute("SELECT id, password FROM users WHERE login = ?", (user.login,))
    result = cursor.fetchone()
    conn.close()

    if result is None or not bcrypt.checkpw(user.password.encode(), result[1].encode()):
        raise HTTPException(status_code=401, detail="Неверные логин или пароль")

    return {"message": "Вход успешен", "user_id": result[0]}
